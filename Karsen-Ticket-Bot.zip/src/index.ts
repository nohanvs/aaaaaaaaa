import {
  Client,
  GatewayIntentBits,
  ActivityType,
  Partials,
} from "discord.js";
import { registerCommands } from "./commands.js";
import { handleInteraction } from "./interactions.js";

const token = process.env.DISCORD_BOT_TOKEN;
const guildId = process.env.DISCORD_GUILD_ID;

if (!token) throw new Error("DISCORD_BOT_TOKEN não definido.");
if (!guildId) throw new Error("DISCORD_GUILD_ID não definido.");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

client.once("clientReady", async (c) => {
  console.log(`✅ Bot online como ${c.user.tag}`);

  c.user.setPresence({
    status: "dnd",
    activities: [
      {
        name: "dev novak9j",
        type: ActivityType.Playing,
      },
    ],
  });

  try {
    await registerCommands(token, c.user.id, guildId!);
    console.log(`✅ Comandos registrados no servidor ${guildId}`);
  } catch (err: any) {
    if (err?.code === 50001) {
      console.warn(
        `⚠️ Não foi possível registrar comandos.\n` +
        `   Re-convide o bot com o escopo "applications.commands":\n` +
        `   https://discord.com/oauth2/authorize?client_id=${c.user.id}&scope=bot+applications.commands&permissions=8`
      );
    } else {
      console.error("❌ Erro ao registrar comandos:", err);
    }
  }
});

client.on("interactionCreate", (interaction) =>
  handleInteraction(interaction)
);

client.on("error", (err) => {
  console.error("❌ Erro no client:", err);
});

client.login(token);

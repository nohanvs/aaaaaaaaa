import {
  Interaction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  TextChannel,
  GuildMember,
  ChatInputCommandInteraction,
  ButtonInteraction,
  ChannelType,
  AttachmentBuilder,
} from "discord.js";
import path from "path";
import { fileURLToPath } from "url";
import { createTicket, closeTicket } from "./ticketManager.js";
import { getGuildConfig, setGuildConfig, addStaffRole, removeStaffRole } from "./configStore.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SUPORTE_IMG = path.join(__dirname, "..", "assets", "suporte.png");

export async function handleInteraction(interaction: Interaction) {
  if (interaction.isChatInputCommand()) {
    await handleCommand(interaction as ChatInputCommandInteraction);
  } else if (interaction.isButton()) {
    await handleButton(interaction as ButtonInteraction);
  }
}

async function handleCommand(interaction: ChatInputCommandInteraction) {
  const { commandName, guild, member } = interaction;

  if (!guild || !member) return;

  if (commandName === "ticket-setup") {
    await interaction.deferReply({ ephemeral: true });

    const attachment = new AttachmentBuilder(SUPORTE_IMG, { name: "suporte.png" });

    const embed = new EmbedBuilder()
      .setTitle("🦣 SUPORTE — KarsenGG 🦣")
      .setDescription(
        "Este canal é destinado ao suporte oficial da organização. Caso você tenha alguma dúvida, problema ou precise de ajuda relacionada ao servidor ou à organização, utilize este espaço para entrar em contato com a equipe de staff.\n\n" +
        "📌 **Utilize o suporte para:**\n" +
        "• Reportar problemas dentro do servidor\n" +
        "• Tirar dúvidas sobre cargos ou funcionamento da organização\n" +
        "• Fazer denúncias de membros\n" +
        "• Resolver questões relacionadas à comunidade ou às lines de Free Fire\n\n" +
        "⚠️ **Orientações:**\n" +
        "• Explique sua situação de forma clara e objetiva\n" +
        "• Mantenha respeito com todos os membros da equipe\n" +
        "• Aguarde até que um membro da staff responda seu atendimento\n\n" +
        "🦣 Nossa equipe fará o possível para atender você o mais rápido possível."
      )
      .setColor(0xe84545)
      .setImage("attachment://suporte.png")
      .setFooter({ text: "Karsen Gaming • Sistema de Tickets" });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("ticket_duvidas")
        .setLabel("📋 Dúvidas e Reclamações")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("ticket_report")
        .setLabel("⚠️ Reportar")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("ticket_moderador")
        .setLabel("🛡️ Fale com Moderador")
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.channel?.send({
      embeds: [embed],
      files: [attachment],
      components: [row],
    });

    await interaction.editReply({ content: "✅ Painel de suporte enviado!" });
  }

  if (commandName === "fechar") {
    const channel = interaction.channel as TextChannel;
    const guildMember = member as GuildMember;

    if (!channel.name.startsWith("ticket-")) {
      await interaction.reply({
        content: "❌ Este comando só pode ser usado dentro de um ticket.",
        ephemeral: true,
      });
      return;
    }

    await interaction.reply({ content: "🔒 Fechando o ticket...", ephemeral: true });
    await closeTicket(channel, guildMember);
  }

  if (commandName === "setup") {
    const sub = interaction.options.getSubcommand();

    if (sub === "adicionar-cargo") {
      const role = interaction.options.getRole("cargo", true);
      addStaffRole(guild.id, role.id);

      const cfg = getGuildConfig(guild.id);
      const allRoles = (cfg.staffRoleIds ?? [])
        .map((id) => guild.roles.cache.get(id))
        .filter(Boolean)
        .map((r) => `• ${r}`)
        .join("\n");

      const embed = new EmbedBuilder()
        .setTitle("✅ Cargo Adicionado")
        .setDescription(`O cargo ${role} agora tem acesso aos tickets.\n\n**Cargos com acesso:**\n${allRoles}`)
        .setColor(0x57f287)
        .setFooter({ text: "Karsen Gaming • Setup" })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === "remover-cargo") {
      const role = interaction.options.getRole("cargo", true);
      removeStaffRole(guild.id, role.id);

      const cfg = getGuildConfig(guild.id);
      const allRoles = (cfg.staffRoleIds ?? [])
        .map((id) => guild.roles.cache.get(id))
        .filter(Boolean)
        .map((r) => `• ${r}`)
        .join("\n");

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Cargo Removido")
        .setDescription(
          `O cargo ${role} foi removido do acesso aos tickets.\n\n**Cargos com acesso:**\n${allRoles || "Nenhum cargo configurado."}`
        )
        .setColor(0xed4245)
        .setFooter({ text: "Karsen Gaming • Setup" })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === "logs") {
      const channel = interaction.options.getChannel("canal", true);

      if (channel.type !== ChannelType.GuildText) {
        await interaction.reply({
          content: "❌ Selecione um canal de texto.",
          ephemeral: true,
        });
        return;
      }

      setGuildConfig(guild.id, { logChannelId: channel.id });

      const embed = new EmbedBuilder()
        .setTitle("✅ Canal de Logs Configurado")
        .setDescription(`Os logs de tickets serão enviados em ${channel}.`)
        .setColor(0x57f287)
        .setFooter({ text: "Karsen Gaming • Setup" })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === "ver") {
      const cfg = getGuildConfig(guild.id);

      const staffRoles = (cfg.staffRoleIds ?? [])
        .map((id) => guild.roles.cache.get(id))
        .filter(Boolean)
        .map((r) => `• ${r}`)
        .join("\n");

      const logChannel = cfg.logChannelId
        ? guild.channels.cache.get(cfg.logChannelId)
        : null;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Configurações Atuais — Karsen Gaming")
        .addFields(
          {
            name: "🛡️ Cargos com Acesso aos Tickets",
            value: staffRoles || "❌ Nenhum cargo configurado",
            inline: false,
          },
          {
            name: "📋 Canal de Logs",
            value: logChannel ? `${logChannel}` : "❌ Não configurado",
            inline: false,
          }
        )
        .setColor(0xe84545)
        .setFooter({ text: "Karsen Gaming • Setup" })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
}

async function handleButton(interaction: ButtonInteraction) {
  const { customId, guild, member } = interaction;

  if (!guild || !member) return;

  if (
    customId === "ticket_duvidas" ||
    customId === "ticket_report" ||
    customId === "ticket_moderador"
  ) {
    await interaction.deferReply({ ephemeral: true });

    const type = customId.replace("ticket_", "");
    const guildMember = member as GuildMember;

    const channel = await createTicket(guild, guildMember, type);

    if (!channel) {
      await interaction.editReply({ content: "❌ Erro ao criar o ticket." });
      return;
    }

    await interaction.editReply({
      content: `✅ Ticket aberto! Acesse: ${channel}`,
    });
  }

  if (customId === "ticket_close") {
    const channel = interaction.channel as TextChannel;
    const guildMember = member as GuildMember;

    if (!channel.name.startsWith("ticket-")) {
      await interaction.reply({
        content: "❌ Este botão só funciona dentro de um ticket.",
        ephemeral: true,
      });
      return;
    }

    await interaction.reply({ content: "🔒 Fechando o ticket...", ephemeral: true });
    await closeTicket(channel, guildMember);
  }
}

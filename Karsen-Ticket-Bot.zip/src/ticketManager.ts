import {
  Guild,
  GuildMember,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  TextChannel,
  ChannelType,
  ColorResolvable,
} from "discord.js";
import { getGuildConfig } from "./configStore.js";

const ticketTypes: Record<
  string,
  { label: string; color: ColorResolvable; description: string; emoji: string }
> = {
  duvidas: {
    label: "Dúvidas e Reclamações",
    emoji: "📋",
    color: "#5865F2",
    description: "Tire dúvidas ou registre reclamações sobre o servidor.",
  },
  report: {
    label: "Report",
    emoji: "⚠️",
    color: "#ED4245",
    description: "Reporte membros ou situações problemáticas.",
  },
  moderador: {
    label: "Fale com Moderador",
    emoji: "🛡️",
    color: "#57F287",
    description: "Fale diretamente com a equipe de moderação.",
  },
};

export async function createTicket(
  guild: Guild,
  member: GuildMember,
  type: string
): Promise<TextChannel | null> {
  const ticketInfo = ticketTypes[type];
  if (!ticketInfo) return null;

  const guildConfig = getGuildConfig(guild.id);

  let category = guild.channels.cache.find(
    (c) => c.type === ChannelType.GuildCategory && c.name === "🎫 Tickets"
  );

  if (!category) {
    category = await guild.channels.create({
      name: "🎫 Tickets",
      type: ChannelType.GuildCategory,
    });
  }

  const channelName = `ticket-${member.user.username.toLowerCase().replace(/[^a-z0-9]/g, "")}-${type}`;

  const existing = guild.channels.cache.find(
    (c) =>
      c.type === ChannelType.GuildText &&
      c.name === channelName &&
      (c as TextChannel).parentId === category!.id
  );

  if (existing) {
    return existing as TextChannel;
  }

  const staffRoles = (guildConfig.staffRoleIds ?? [])
    .map((id) => guild.roles.cache.get(id))
    .filter(Boolean);

  const channel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: [
      {
        id: guild.roles.everyone,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: member.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
      ...staffRoles.map((role) => ({
        id: role!.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.ManageMessages,
        ],
      })),
    ],
  });

  const embed = new EmbedBuilder()
    .setTitle(`${ticketInfo.emoji} ${ticketInfo.label}`)
    .setDescription(
      `Olá ${member}, seu ticket foi aberto!\n\n**Motivo:** ${ticketInfo.description}\n\nExplique sua situação de forma clara e aguarde um membro da staff responder.\n\n> Mantenha o respeito com todos os membros da equipe.`
    )
    .setColor(ticketInfo.color)
    .setFooter({ text: "Karsen Gaming • Sistema de Tickets" })
    .setTimestamp();

  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("ticket_close")
      .setLabel("🔒 Fechar Ticket")
      .setStyle(ButtonStyle.Danger)
  );

  const staffMentions = staffRoles.map((r) => `${r}`).join(" ");
  await channel.send({
    content: `${member}${staffMentions ? ` | ${staffMentions}` : ""}`,
    embeds: [embed],
    components: [closeRow],
  });

  if (guildConfig.logChannelId) {
    const logChannel = guild.channels.cache.get(guildConfig.logChannelId) as TextChannel | undefined;
    if (logChannel) {
      const logEmbed = new EmbedBuilder()
        .setTitle("📩 Novo Ticket Aberto")
        .addFields(
          { name: "Usuário", value: `${member} (${member.user.tag})`, inline: true },
          { name: "Tipo", value: `${ticketInfo.emoji} ${ticketInfo.label}`, inline: true },
          { name: "Canal", value: `${channel}`, inline: true }
        )
        .setColor("#5865F2")
        .setFooter({ text: "Karsen Gaming • Logs de Tickets" })
        .setTimestamp();
      await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
    }
  }

  return channel;
}

export async function closeTicket(
  channel: TextChannel,
  closedBy: GuildMember
): Promise<void> {
  const guildConfig = getGuildConfig(channel.guild.id);

  const embed = new EmbedBuilder()
    .setTitle("🔒 Ticket Encerrado")
    .setDescription(
      `Este ticket foi fechado por ${closedBy}.\nO canal será deletado em **5 segundos**.`
    )
    .setColor("#ED4245")
    .setFooter({ text: "Karsen Gaming • Sistema de Tickets" })
    .setTimestamp();

  await channel.send({ embeds: [embed] });

  if (guildConfig.logChannelId) {
    const logChannel = channel.guild.channels.cache.get(guildConfig.logChannelId) as TextChannel | undefined;
    if (logChannel) {
      const logEmbed = new EmbedBuilder()
        .setTitle("🔒 Ticket Fechado")
        .addFields(
          { name: "Canal", value: channel.name, inline: true },
          { name: "Fechado por", value: `${closedBy} (${closedBy.user.tag})`, inline: true }
        )
        .setColor("#ED4245")
        .setFooter({ text: "Karsen Gaming • Logs de Tickets" })
        .setTimestamp();
      await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
    }
  }

  setTimeout(async () => {
    await channel.delete("Ticket fechado").catch(() => {});
  }, 5000);
}

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, "..", "guild-configs.json");

export interface GuildConfig {
  staffRoleIds?: string[];
  logChannelId?: string;
  ticketCategoryId?: string;
}

function loadAll(): Record<string, GuildConfig> {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, "utf-8"));
    }
  } catch {}
  return {};
}

function saveAll(data: Record<string, GuildConfig>) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(data, null, 2), "utf-8");
}

export function getGuildConfig(guildId: string): GuildConfig {
  return loadAll()[guildId] ?? {};
}

export function setGuildConfig(guildId: string, updates: Partial<GuildConfig>) {
  const all = loadAll();
  all[guildId] = { ...(all[guildId] ?? {}), ...updates };
  saveAll(all);
}

export function addStaffRole(guildId: string, roleId: string) {
  const all = loadAll();
  const cfg = all[guildId] ?? {};
  const ids = new Set(cfg.staffRoleIds ?? []);
  ids.add(roleId);
  all[guildId] = { ...cfg, staffRoleIds: [...ids] };
  saveAll(all);
}

export function removeStaffRole(guildId: string, roleId: string) {
  const all = loadAll();
  const cfg = all[guildId] ?? {};
  const ids = (cfg.staffRoleIds ?? []).filter((id) => id !== roleId);
  all[guildId] = { ...cfg, staffRoleIds: ids };
  saveAll(all);
}

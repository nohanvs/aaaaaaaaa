import { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } from "discord.js";

const commands = [
  new SlashCommandBuilder()
    .setName("ticket-setup")
    .setDescription("Envia o painel de suporte da Karsen Gaming neste canal.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .toJSON(),

  new SlashCommandBuilder()
    .setName("fechar")
    .setDescription("Fecha o ticket atual.")
    .toJSON(),

  new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configura o sistema de tickets da Karsen Gaming.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("adicionar-cargo")
        .setDescription("Adiciona um cargo com acesso aos tickets.")
        .addRoleOption((opt) =>
          opt
            .setName("cargo")
            .setDescription("Cargo da staff/suporte")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("remover-cargo")
        .setDescription("Remove um cargo do acesso aos tickets.")
        .addRoleOption((opt) =>
          opt
            .setName("cargo")
            .setDescription("Cargo a remover")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("logs")
        .setDescription("Define o canal onde os logs de tickets serão enviados.")
        .addChannelOption((opt) =>
          opt
            .setName("canal")
            .setDescription("Canal de logs")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("ver")
        .setDescription("Mostra as configurações atuais do sistema de tickets.")
    )
    .toJSON(),
];

export async function registerCommands(
  token: string,
  clientId: string,
  guildId: string
) {
  const rest = new REST({ version: "10" }).setToken(token);

  await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
    body: commands,
  });
}
